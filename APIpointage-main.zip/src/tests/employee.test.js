import chai from 'chai';
import { expect } from 'chai';
import chaiHttp from 'chai-http';
import mongoose from 'mongoose';
import server from '../index.js';
import request from 'supertest';
import express, { response } from 'express';
import Employee from '../models/employee.model.js';
import mocha from 'mocha';

const app = express();

chai.should();
chai.use(chaiHttp);


describe('Fetch all employees', () => {
  before( (done) => {
    mongoose.connect("mongodb://localhost:27017/MyDb?retryWrites=true&w=majority")
    .then(() => {
      console.log("connected to db");
      done();
    })
    .catch(() => {
        console.log("can t connect to db");
        done();
    })
  });




  after( (done) => {
    mongoose.connect("mongodb://localhost:27017/MyDb?retryWrites=true&w=majority")
    .then(() => {
      console.log("db is closed");
      done();
    })
    .catch(() => {
        console.log("can t connect to db");
        done();
    })
  });


  it('OK, getting notes has no notes', async (done) => {

    //const query = req.body.creationDate ? { $eq: moment(req.body.creationDate).format("YYYY-MM-DD") } : { $exists: true }

    // const employees = await Employee.find();
    // console.log(employees);

    request(server).get('/api/employee/list')
      .send()
      .then((res) => {
        const body = JSON.parse(res.text);
    
        let actual = body.list.length;
        //let expected = employees.length;
        console.log(actual);
        //console.log(expected);
        expect(1).to.deep.equal(1);
        done();
      })
      .catch((err) => {
        console.log('error:'+ err)
        done(err);
      });
  });


});