API de pointage

Description
    

Test Cases

1 when a non existing user checks in/out send a user not found message

2 when user check out without checking in first send error message

3 when user check in multiple time in the same day with checking out send error message